OVERLEAF-EKSPORT — HOVEDOPGAVE (VEKTOR-PDF + LATEX)
=====================================================

Indhold i denne mappe / dette arkiv (overleaf-export.zip):
- hovedopgave.tex         : Hovedrapporten (starter med forsiden, inkl. 14 kerne-/arkitekturdiagrammer i vektor-PDF)
- bilag-diagrammer.tex    : Modulært bilag med de øvrige 31 vektor-PDF'er (samlet 45 vektor-diagrammer)
- diagrams/*.pdf          : 45 beskårne enkelt-sides vektor-PDF'er eksporteret med Chrome Skia PDF uden rasterfiltre
- diagrams-manifest.json  : Maskinlæsbar oversigt over kilder, orientering (portrait/landscape), dimensioner og hashes

1. UPLOAD TIL OVERLEAF (ANBEFALET WORKFLOW)
-------------------------------------------
1) Gå til Overleaf -> "New Project" -> "Upload Project".
2) Vælg filen `overleaf-export.zip` (hovedopgave.tex ligger direkte i roden af arkivet).
3) Overleaf sætter automatisk kompilatoren til pdfLaTeX (ellers Menu -> Compiler -> pdfLaTeX).
4) Der kræves IKKE `--shell-escape`, Inkscape, Mermaid CLI i skyen eller eksterne billedværktøjer:
   alle diagrammer ligger allerede som rene vektor-PDF'er under `diagrams/` og indlæses via `\graphicspath`.

2. LOKAL GEN-GENERERING AF ALLE 45 VEKTOR-PDF'ER
------------------------------------------------
Fra projektets rodmappe (`z:\home\work\projects\api` / repo-roden) køres:

    npm run diagrams:pdf

Scriptet `scripts/render-diagrams-pdf.mjs` læser `.mmd` / `.puml`-filerne samt blokkene i
`HOVEDOPGAVE_DIAGRAMMER.md`, injicerer det ensartede blå/hvide tema i utematiserede diagrammer,
fjerner SVG-filtre der ellers ville tvinge rasterisering, og skriver alle 45 enkelt-sides
vektor-PDF'er til `overleaf-export/diagrams/` samt opdaterer `diagrams-manifest.json`.

3. TIL-/FRAVALG AF BILAG OG ENKELTDIAGRAMMER
--------------------------------------------
- Alle 31 supplerende bilagsdiagrammer indlæses automatisk via linjen nederst i `hovedopgave.tex`:
      \IfFileExists{bilag-diagrammer.tex}{\input{bilag-diagrammer}}{}
  Vil du midlertidigt udelade diagram-bilagene, kan filen `bilag-diagrammer.tex` blot slettes
  eller udkommenteres i `hovedopgave.tex`.
- I `bilag-diagrammer.tex` er hvert diagram markeret med kommentaren:
      % --- <slug> ---
  Du kan frit udkommentere eller flytte individuelle figurer ud fra deres `<slug>`.
- Brede diagrammer (billedformat >= 1,35) roteres automatisk til tværformat via `\landscapefigure`
  (`pdflscape`-pakken), mens høje diagrammer vises stående via `\portraitfigure`.
